package Hassan.Ouadouch.keynoteservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeynoteServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
